"""Spatio-temporal risk model: P(at least one accident in zone z during 4h block b on day d)."""
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.metrics import (precision_score, recall_score, f1_score, roc_auc_score, accuracy_score,
                             confusion_matrix, roc_curve, average_precision_score)
from config import *

FEATURES = ["block", "dow", "month", "is_weekend", "is_friday", "is_payday", "rain", "zone_rate",
            "zone_rain_ratio", "zone_rush_ratio", "is_highway", "is_urban", "is_industrial"]


def build_panel(df, hs, weather):
    """One row per hotspot x day x 4h-block. Label = at least one accident happened there."""
    days = pd.date_range(START, END, freq="D")
    z = pd.MultiIndex.from_product([hs.cluster.values, days, range(6)], names=["cluster", "date", "block"]).to_frame(index=False)
    ev = df[df.cluster >= 0].copy()
    ev["date"] = ev.datetime.dt.normalize(); ev["block"] = ev.datetime.dt.hour // 4
    cnt = ev.groupby(["cluster", "date", "block"]).size().rename("n").reset_index()
    z = z.merge(cnt, how="left", on=["cluster", "date", "block"]).fillna({"n": 0})
    z["y"] = (z.n > 0).astype(int)
    z = z.merge(weather, how="left", on=["date", "block"]).fillna({"rain": 0})   # weather feed, known for every block
    d = z.date.dt
    z["dow"], z["month"] = d.dayofweek, d.month
    z["is_weekend"] = (z.dow >= 5).astype(int); z["is_friday"] = (z.dow == 4).astype(int)
    z["is_payday"] = ((d.day >= 24) | (d.day <= 2)).astype(int)
    rt = hs.set_index("cluster").road_type
    for t in ["highway", "urban", "industrial"]:
        z[f"is_{t}"] = (z.cluster.map(rt) == t).astype(int)
    return z


def add_zone_history(z):
    """Zone-level history computed from TRAIN years only (prevents data leakage)."""
    tr = z[z.date <= TRAIN_END]
    zr = tr.groupby("cluster").y.mean().rename("zone_rate")
    zrain = (tr[tr.rain == 1].groupby("cluster").y.mean() / zr).rename("zone_rain_ratio")
    zrush = (tr[tr.block.isin([1, 4])].groupby("cluster").y.mean() / zr).rename("zone_rush_ratio")
    z = z.join(zr, on="cluster").join(zrain, on="cluster").join(zrush, on="cluster")
    return z.fillna({"zone_rain_ratio": 1.0, "zone_rush_ratio": 1.0})


def split(z):
    tr, va, te = z[z.date <= TRAIN_END], z[(z.date > TRAIN_END) & (z.date <= VAL_END)], z[z.date > VAL_END]
    return tr, va, te


def metrics(y, p, thr):
    yh = (p >= thr).astype(int)
    return dict(accuracy=accuracy_score(y, yh), precision=precision_score(y, yh), recall=recall_score(y, yh),
                f1=f1_score(y, yh), roc_auc=roc_auc_score(y, p), pr_auc=average_precision_score(y, p))


def best_threshold(y, p):
    ts = np.linspace(.05, .8, 76); f = [f1_score(y, (p >= t).astype(int)) for t in ts]
    return float(ts[int(np.argmax(f))])


def train_and_evaluate(z):
    tr, va, te = split(z)
    print(f"[risk] rows train/val/test = {len(tr)}/{len(va)}/{len(te)}; accident rate {tr.y.mean():.1%} (imbalanced!)")
    models = {
        "Baseline (zone history only)": None,
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=500, class_weight="balanced")),
        "Random Forest": RandomForestClassifier(n_estimators=250, min_samples_leaf=20, class_weight="balanced_subsample", n_jobs=-1, random_state=SEED),
        "Gradient Boosting": GradientBoostingClassifier(random_state=SEED),
    }
    res, fitted, valprob = {}, {}, {}
    for name, mdl in models.items():
        if mdl is None:
            pv, pt = va.zone_rate.values, te.zone_rate.values
        else:
            mdl.fit(tr[FEATURES], tr.y); fitted[name] = mdl
            pv, pt = mdl.predict_proba(va[FEATURES])[:, 1], mdl.predict_proba(te[FEATURES])[:, 1]
        thr = best_threshold(va.y, pv)                               # threshold chosen on VALIDATION only
        res[name] = dict(threshold=thr, **metrics(te.y, pt, thr)); valprob[name] = pt
    # --- improve accuracy: hyper-parameter tuning with time-series cross-validation -----------------
    gs = GridSearchCV(GradientBoostingClassifier(random_state=SEED),
                      {"n_estimators": [100, 200], "max_depth": [2, 3], "learning_rate": [0.05, 0.1]},
                      cv=TimeSeriesSplit(3), scoring="roc_auc", n_jobs=-1).fit(tr[FEATURES], tr.y)
    best = gs.best_estimator_; name = "Gradient Boosting (tuned)"
    pv, pt = best.predict_proba(va[FEATURES])[:, 1], best.predict_proba(te[FEATURES])[:, 1]
    thr = best_threshold(va.y, pv); res[name] = dict(threshold=thr, **metrics(te.y, pt, thr)); valprob[name] = pt; fitted[name] = best
    print("[risk] best GridSearch params:", gs.best_params_)
    table = pd.DataFrame(res).T
    champion = table.roc_auc.idxmax()
    print(table.round(3).to_string()); print("[risk] champion model:", champion)
    # per-year drift check
    zt = z.copy(); zt["p"] = fitted[champion].predict_proba(zt[FEATURES])[:, 1]
    drift = zt[zt.date > TRAIN_END].groupby(zt.date.dt.year).apply(lambda g: roc_auc_score(g.y, g.p))
    return table, champion, fitted, tr, va, te, valprob, drift


def plots(table, champion, fitted, te, probs):
    mdl = fitted[champion]; p = probs[champion]; thr = table.loc[champion, "threshold"]
    fig, axs = plt.subplots(1, 3, figsize=(15, 4.3))
    cm = confusion_matrix(te.y, (p >= thr).astype(int))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=axs[0], xticklabels=["No accident", "Accident"], yticklabels=["No accident", "Accident"])
    axs[0].set(title=f"Confusion matrix – {champion}\n(test year 2025, threshold {thr:.2f})", xlabel="Predicted", ylabel="Actual")
    for n, pr in probs.items():
        fpr, tpr, _ = roc_curve(te.y, pr); axs[1].plot(fpr, tpr, label=f"{n} (AUC {table.loc[n,'roc_auc']:.3f})", lw=2 if n == champion else 1)
    axs[1].plot([0, 1], [0, 1], "k--", lw=.8); axs[1].set(title="ROC curves (test set)", xlabel="False positive rate", ylabel="True positive rate"); axs[1].legend(fontsize=6.5)
    imp = pd.Series(getattr(mdl, "feature_importances_", np.zeros(len(FEATURES))), index=FEATURES).sort_values()
    imp.plot.barh(ax=axs[2], color="#3b6ea5"); axs[2].set_title("Feature importance")
    fig.tight_layout(); fig.savefig(OUT / "02_model_evaluation.png", dpi=150); plt.close(fig)


def save(bundle):
    joblib.dump(bundle, OUT / "risk_model.joblib")


def capture_rate(y, p, fracs=(0.1, 0.2, 0.3)):
    """Operational metric: if patrols cover only the top-X% highest-risk zone-windows, what share of accidents do they reach?"""
    order = np.argsort(-p); yy = np.asarray(y)[order]; tot = yy.sum()
    return {f"top {int(f*100)}% windows": float(yy[:int(len(yy) * f)].sum() / tot) for f in fracs}


def oracle_auc(te, hs, lam):
    """Best score ANY model could reach on simulated data (uses the true accident intensity)."""
    zi = {r.cluster: int(np.argmin([(r.lat - z[1]) ** 2 + (r.lon - z[2]) ** 2 for z in ZONES])) for r in hs.itertuples()}
    days = pd.date_range(START, END, freq="D"); di = pd.Series(range(len(days)), index=days)
    l = lam[di.loc[te.date].values, te.cluster.map(zi).values, te.block.values]
    return roc_auc_score(te.y, 1 - np.exp(-l)), 1 - np.exp(-l)
