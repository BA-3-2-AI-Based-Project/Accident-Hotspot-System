"""Spatial hotspot detection with DBSCAN (haversine distance) + map / heatmap output."""
import numpy as np, pandas as pd, folium
from folium.plugins import HeatMap
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from config import *

EARTH_KM = 6371.0088


def detect(df, eps_m=450, min_samples=60):
    """Add 'cluster' (-1 = not part of a hotspot) and return the hotspot summary table."""
    coords = np.radians(df[["lat", "lon"]].values)
    db = DBSCAN(eps=eps_m / 1000 / EARTH_KM, min_samples=min_samples, metric="haversine", algorithm="ball_tree").fit(coords)
    df = df.copy(); df["cluster"] = db.labels_
    rows = []
    for c, g in df[df.cluster >= 0].groupby("cluster"):
        clat, clon = g.lat.mean(), g.lon.mean()
        # name = nearest known place (stand-in for reverse geocoding)
        k = int(np.argmin([(clat - z[1]) ** 2 + (clon - z[2]) ** 2 for z in ZONES]))
        rows.append(dict(cluster=c, name=ZONES[k][0], lat=clat, lon=clon, accidents=len(g),
                         fatal=int((g.severity == "fatal").sum()), road_type=g.road_type.mode()[0],
                         severity_score=(g.severity.map({"minor": 1, "serious": 3, "fatal": 10, "unknown": 1}).sum())))
    hs = pd.DataFrame(rows).sort_values("severity_score", ascending=False).reset_index(drop=True)
    hs["rank"] = hs.index + 1
    print(f"[hotspots] DBSCAN found {len(hs)} hotspots; {int((df.cluster>=0).mean()*100)}% of accidents fall inside one")
    return df, hs


def plot_hotspots(df, hs):
    fig, ax = plt.subplots(figsize=(8, 6.5))
    bg = df[df.cluster < 0]; ax.scatter(bg.lon, bg.lat, s=2, c="#c8c8c8", label="Scattered accidents")
    cm = plt.get_cmap("tab10")
    for c, g in df[df.cluster >= 0].groupby("cluster"):
        ax.scatter(g.lon, g.lat, s=4, color=cm(c % 10))
    for _, r in hs.iterrows():
        ax.annotate(f"#{r['rank']} {r['name']}", (r.lon, r.lat), fontsize=7, xytext=(6, 6), textcoords="offset points",
                    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=.8))
    ax.set_title("Accident hotspots detected by DBSCAN (simulated Vaal data)"); ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
    ax.legend(loc="lower left", markerscale=4); fig.tight_layout(); fig.savefig(OUT / "01_hotspots_dbscan.png", dpi=150); plt.close(fig)


def build_map(df, hs, risk_now=None):
    """Interactive heatmap + hotspot markers -> HTML (open in any browser)."""
    m = folium.Map(location=[df.lat.mean(), df.lon.mean()], zoom_start=11, tiles="CartoDB positron")
    HeatMap(df[["lat", "lon"]].values.tolist(), radius=9, blur=12, min_opacity=.25).add_to(m)
    mx = hs.accidents.max()
    for _, r in hs.iterrows():
        col = "red" if r["rank"] <= 3 else "orange" if r["rank"] <= 6 else "green"
        extra = f"<br>Predicted risk now: <b>{risk_now[r['name']]}</b>" if risk_now and r["name"] in risk_now else ""
        folium.CircleMarker([r.lat, r.lon], radius=8 + 14 * r.accidents / mx, color=col, fill=True, fill_opacity=.45,
            popup=folium.Popup(f"<b>#{r['rank']} {r['name']}</b><br>{r.accidents} accidents, {r.fatal} fatal<br>Road type: {r.road_type}{extra}", max_width=260)).add_to(m)
    m.save(OUT / "hotspot_map.html")
