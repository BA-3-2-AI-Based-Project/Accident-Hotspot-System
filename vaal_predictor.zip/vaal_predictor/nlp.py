"""Natural Language Processing: classify the CAUSE of an accident from its free-text police/EMS narrative."""
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from config import *

VAGUE_WORDS = ("collision between", "accident reported", "crash at the", "two vehicles involved")


def train(df):
    d = df[df.narrative.str.len() > 0]
    Xtr, Xte, ytr, yte = train_test_split(d.narrative, d.cause, test_size=.25, random_state=SEED, stratify=d.cause)
    pipe = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2, stop_words="english"), LogisticRegression(max_iter=1000, class_weight="balanced"))
    pipe.fit(Xtr, ytr); p = pipe.predict(Xte)
    vague = Xte.str.lower().str.startswith(VAGUE_WORDS)
    res = dict(accuracy_all=accuracy_score(yte, p), macro_f1_all=f1_score(yte, p, average="macro"),
               accuracy_descriptive=accuracy_score(yte[~vague], p[~vague]), accuracy_vague=accuracy_score(yte[vague], p[vague]))
    print("[nlp]", {k: round(v, 3) for k, v in res.items()})
    cm = confusion_matrix(yte, p, labels=CAUSES)
    fig, ax = plt.subplots(figsize=(7.5, 6)); sns.heatmap(cm, annot=True, fmt="d", cmap="Purples", xticklabels=CAUSES, yticklabels=CAUSES, ax=ax, cbar=False)
    ax.set(title="NLP: cause-of-accident classifier (narrative text)", xlabel="Predicted", ylabel="Actual"); plt.xticks(rotation=40, ha="right"); fig.tight_layout(); fig.savefig(OUT / "05_nlp_confusion.png", dpi=150); plt.close(fig)
    vec, clf = pipe.steps[0][1], pipe.steps[1][1]; terms = np.array(vec.get_feature_names_out())
    top = {c: list(terms[np.argsort(clf.coef_[i])[-5:][::-1]]) for i, c in enumerate(clf.classes_)}
    return pipe, res, top


def explain(pipe, text):
    probs = pipe.predict_proba([text])[0]; i = int(np.argmax(probs))
    return pipe.classes_[i], float(probs[i])
