"""'VaalBot' - rule-based conversational assistant on top of the trained risk model + NLP model.
Understands: location, weekday/day, time of day, rain; intents: risk, safest time, top hotspots, analyse a report, help."""
import re, datetime as dt
import numpy as np, pandas as pd
from config import *
import risk_model as rm

ALIASES = {"vanderbijlpark": ["vanderbijlpark", "r59", "vdb"], "vereeniging": ["vereeniging", "cbd"], "sebokeng": ["sebokeng", "r82"],
           "evaton": ["evaton"], "sasolburg": ["sasolburg", "r42", "sasol"], "meyerton": ["meyerton", "n1"], "sharpeville": ["sharpeville"],
           "three rivers": ["three rivers"], "boipatong": ["boipatong", "bophelong"], "barrage": ["barrage"]}
TIME_WORDS = {"midnight": 1, "night": 22, "late": 22, "dawn": 5, "early morning": 5, "morning": 7, "noon": 12, "midday": 12, "lunch": 12,
              "afternoon": 14, "rush": 17, "evening": 18, "after work": 17, "sunset": 18}
LEVEL_ADVICE = {"Low": "Normal conditions - drive as usual.", "Moderate": "Stay alert and keep a safe following distance.",
                "High": "Take extra care: reduce speed, avoid distractions, consider an alternative route.",
                "Very high": "Avoid this area in this window if you can; if not, slow right down and leave extra space."}


class RiskPredictor:
    def __init__(self, bundle):
        self.m, self.hs, self.zf, self.cuts = bundle["model"], bundle["hotspots"], bundle["zone_features"], bundle["risk_cuts"]

    def level(self, p):
        return "Low" if p < self.cuts[0] else "Moderate" if p < self.cuts[1] else "High" if p < self.cuts[2] else "Very high"

    def predict(self, cluster, dow, block, rain, month=None, day_of_month=15):
        month = month or dt.date.today().month
        f = dict(block=block, dow=dow, month=month, is_weekend=int(dow >= 5), is_friday=int(dow == 4), is_payday=int(day_of_month >= 24 or day_of_month <= 2),
                 rain=int(rain), **self.zf[cluster])
        return float(self.m.predict_proba(pd.DataFrame([f])[rm.FEATURES])[0, 1])


class VaalBot:
    def __init__(self, bundle, nlp_pipe):
        self.rp, self.nlp = RiskPredictor(bundle), nlp_pipe
        self.hs = bundle["hotspots"]

    # ---- language understanding -------------------------------------------------------------
    def _zones(self, t):
        hit = [k for k, al in ALIASES.items() if any(re.search(rf"\b{re.escape(a)}\b", t) for a in al)]
        if not hit: return []
        sel = self.hs[self.hs.name.str.lower().apply(lambda n: any(k in n or (k == "boipatong" and "bophelong" in n) for k in hit))]
        return list(sel.itertuples())

    def _day(self, t):
        for i, d in enumerate(DAYS):
            if d.lower() in t or d[:3].lower() + " " in t + " ": return i
        if "tomorrow" in t: return (dt.date.today().weekday() + 1) % 7
        if "today" in t or "tonight" in t: return dt.date.today().weekday()
        return None

    def _hour(self, t):
        m = re.search(r"\b(\d{1,2})\s*[:h]\s*(\d{2})?\b", t) or None
        if m and int(m.group(1)) < 24: return int(m.group(1))
        m = re.search(r"\b(\d{1,2})\s*(am|pm)\b", t)
        if m:
            h = int(m.group(1)) % 12; return h + (12 if m.group(2) == "pm" else 0)
        for w, h in TIME_WORDS.items():
            if w in t: return h
        return None

    # ---- replies ----------------------------------------------------------------------------
    def reply(self, text):
        t = text.lower().strip()
        if re.match(r"^(hi|hello|hey|howzit|good (morning|afternoon|evening))\b", t) and len(t) < 30:
            return "Hello! I'm VaalBot. Ask me e.g. 'How risky is Vereeniging on Friday at 17:00 when raining?', 'safest time on the R59 on Saturday', or 'top hotspots'. Type 'help' for more."
        if t in ("help", "?", "what can you do"):
            return ("I can:\n  1. Predict accident risk: 'risk in Sebokeng Monday evening raining'\n  2. Suggest the safest time: 'safest time for Meyerton on Friday'\n"
                    "  3. List the worst hotspots: 'top hotspots'\n  4. Analyse an accident report: 'report: driver was texting and hit a pole'\n  5. Explain the model: 'how accurate are you?'")
        if t.startswith(("report:", "analyse", "analyze")):
            narrative = text.split(":", 1)[1] if ":" in text else re.sub(r"^(analy[sz]e)\s*", "", text, flags=re.I)
            cause, p = self.nlp_explain(narrative.strip())
            return f"From the narrative, the most likely cause is **{cause.replace('_', ' ')}** (confidence {p:.0%})."
        if any(k in t for k in ("accura", "how good", "how does", "model", "reliable")):
            return ("I use a gradient-boosting model trained on 2020-2023 accident history (validated 2024, tested 2025) combined with DBSCAN hotspots. "
                    "My answers are risk PREDICTIONS (a probability), not guarantees. See outputs/metrics.md for the exact test scores.")
        if any(k in t for k in ("top", "worst", "dangerous", "hotspots", "most accident")):
            top = self.hs.head(5)
            return "Top 5 hotspots (by severity-weighted accidents):\n" + "\n".join(f"  #{r.rank} {r.name} - {r.accidents} accidents, {r.fatal} fatal" for r in top.itertuples())
        zones = self._zones(t)
        if not zones:
            return "Which area do you mean? I know: Vanderbijlpark/R59, Vereeniging, Sebokeng/R82, Evaton, Sasolburg, Meyerton, Sharpeville, Three Rivers, Boipatong, Barrage Road."
        dow = self._day(t); hour = self._hour(t); rain = int(bool(re.search(r"\b(rain|raining|rainy|storm|wet|thunder)", t)))
        today = dt.date.today(); dow_eff = today.weekday() if dow is None else dow
        month = today.month
        if any(k in t for k in ("safest", "best time", "when should", "least risky", "avoid")):
            out = []
            for z in zones[:2]:
                ps = [self.rp.predict(z.cluster, dow_eff, b, rain, month) for b in range(6)]
                b = int(np.argmin(ps)); w = int(np.argmax(ps))
                out.append(f"{z.name} on {DAYS[dow_eff]}{' (rain)' if rain else ''}: safest {BLOCKS[b].replace('-', ':00-')}:00 ({self.rp.level(ps[b])}), "
                           f"riskiest {BLOCKS[w].replace('-', ':00-')}:00 ({self.rp.level(ps[w])}, {ps[w]:.0%}).")
            return "\n".join(out)
        if hour is None:
            hour = datetime_hour = dt.datetime.now().hour
        block = hour // 4
        lines = []
        for z in zones[:2]:
            p = self.rp.predict(z.cluster, dow_eff, block, rain, month); lv = self.rp.level(p)
            lines.append(f"{z.name} - {DAYS[dow_eff]} {BLOCKS[block].replace('-', ':00-')}:00{', raining' if rain else ', dry'}:\n"
                         f"  Risk level: {lv.upper()}  (model probability of >=1 accident in that window: {p:.0%})\n  {LEVEL_ADVICE[lv]}")
        return "\n".join(lines)

    def nlp_explain(self, narrative):
        probs = self.nlp.predict_proba([narrative])[0]; i = int(np.argmax(probs)); return self.nlp.classes_[i], float(probs[i])


def chat_loop(bot):
    print("VaalBot ready. Type 'help' for examples, 'quit' to exit.")
    while True:
        try: q = input("\nYou: ")
        except (EOFError, KeyboardInterrupt): break
        if q.strip().lower() in ("quit", "exit", "bye"): print("VaalBot: Stay safe on the roads!"); break
        print("VaalBot:", bot.reply(q))
