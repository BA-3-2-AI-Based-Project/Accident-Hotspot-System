# Evaluation results (simulated Vaal data; test year = 2025)

## Risk model (zone x 4h-block)
|                              |   threshold |   accuracy |   precision |   recall |    f1 |   roc_auc |   pr_auc |
|:-----------------------------|------------:|-----------:|------------:|---------:|------:|----------:|---------:|
| Baseline (zone history only) |        0.07 |      0.778 |       0.076 |    0.292 | 0.121 |     0.59  |    0.067 |
| Logistic Regression          |        0.59 |      0.808 |       0.093 |    0.307 | 0.143 |     0.628 |    0.086 |
| Random Forest                |        0.53 |      0.773 |       0.084 |    0.337 | 0.134 |     0.616 |    0.083 |
| Gradient Boosting            |        0.08 |      0.806 |       0.102 |    0.346 | 0.157 |     0.662 |    0.098 |
| Gradient Boosting (tuned)    |        0.07 |      0.777 |       0.098 |    0.398 | 0.157 |     0.661 |    0.097 |

Champion: **Gradient Boosting**

Theoretical best ROC-AUC on this simulated data (oracle that knows the true accident rates): **0.665**

Share of test-year accidents reached if patrols cover only the highest-risk windows:

|                         |   top 10% windows |   top 20% windows |   top 30% windows |
|:------------------------|------------------:|------------------:|------------------:|
| Random selection        |             0.101 |             0.2   |             0.289 |
| Champion model          |             0.221 |             0.378 |             0.515 |
| Oracle (true intensity) |             0.231 |             0.386 |             0.524 |

Roc-AUC per year after training (model-drift check):

|   year |   roc_auc |
|-------:|----------:|
|   2024 |     0.657 |
|   2025 |     0.662 |

## LSTM daily forecast
|                               |   MAE |   RMSE |
|:------------------------------|------:|-------:|
| Naive: last-7-day mean        | 1.674 |  2.099 |
| Naive: same weekday last week | 2.09  |  2.667 |
| LSTM                          | 1.476 |  1.871 |

## NLP cause classifier
|                      |   score |
|:---------------------|--------:|
| accuracy_all         |   0.798 |
| macro_f1_all         |   0.782 |
| accuracy_descriptive |   1     |
| accuracy_vague       |   0.152 |

Top words per cause:
- animal: vehicle collided, stray animal, stray, animal, collided stray
- distracted_driving: driver, texting collision, driver texting, texting, happened
- drunk_driving: alcohol, suspected, smelled alcohol, smelled, driver smelled
- mechanical_failure: truck, truck broke, broke, broke hit, tyre burst
- pedestrian: pedestrian, crossing, street, street hit, ran street
- speeding: speed, travelling, vehicle travelling, travelling fast, overturned
- wet_road: rain, slammed, slammed median, median, aquaplaned slammed
