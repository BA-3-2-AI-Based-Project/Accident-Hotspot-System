# Real dataset analysis (n=150)

- Period: 2023-01-05 to 2024-11-27
- Day_of_Week column disagrees with the real weekday of Date in 85% of rows (recomputed)
- DBSCAN: 9 hotspots, 16% noise; adjusted Rand vs Location_Name = 0.82

## Hotspot ranking
|   rank |   cluster | location                            |    lat |   lon |   accidents |   fatal |   fatal_pct |   rain_pct | top_cause      | peak_period   |   high_risk_pct |   severity_score |
|-------:|----------:|:------------------------------------|-------:|------:|------------:|--------:|------------:|-----------:|:---------------|:--------------|----------------:|-----------------:|
|      1 |         7 | R57 - Vanderbijlpark to Sasolburg   | -26.68 | 27.8  |          21 |       8 |        0.38 |       0.29 | Jaywalking     | Evening peak  |            0.57 |              105 |
|      2 |         4 | R59 - Vereeniging to Meyerton       | -26.52 | 28.05 |          19 |       7 |        0.37 |       0.26 | Truck Overload | Evening peak  |            0.26 |               96 |
|      3 |         3 | Johannesburg Rd - Vereeniging CBD   | -26.67 | 27.93 |          15 |       7 |        0.47 |       0.4  | Jaywalking     | Evening peak  |            0.47 |               84 |
|      4 |         5 | Frikkie Meyer Blvd - Vanderbijlpark | -26.7  | 27.82 |          17 |       3 |        0.18 |       0.35 | Drunk Driving  | Evening peak  |            0.41 |               62 |
|      5 |         2 | R82 - De Deur Intersection          | -26.38 | 28.02 |          17 |       3 |        0.18 |       0.24 | Jaywalking     | Morning peak  |            0.41 |               62 |
|      6 |         6 | Golden Highway - Sebokeng           | -26.58 | 27.84 |          13 |       4 |        0.31 |       0.08 | Drunk Driving  | Evening peak  |            0.62 |               55 |
|      7 |         8 | Old Vereeniging Road - Evaton       | -26.54 | 27.86 |           9 |       4 |        0.44 |       0.33 | Jaywalking     | Evening peak  |            0.33 |               49 |
|      8 |         0 | General Hertzog Rd - Three Rivers   | -26.67 | 27.96 |           8 |       1 |        0.12 |       0.38 | Drunk Driving  | Evening peak  |            0.5  |               25 |
|      9 |         1 | Moshoeshoe Rd - Sharpeville         | -26.67 | 27.87 |           7 |       1 |        0.14 |       0.71 | Drunk Driving  | Evening peak  |            0.57 |               20 |

## Cross-validated models
| target     | model                   |   accuracy |   accuracy_sd |   macro_f1 |   perm_p_value |
|:-----------|:------------------------|-----------:|--------------:|-----------:|---------------:|
| Severity   | Majority-class baseline |      0.367 |         0     |      0.179 |        nan     |
| Severity   | Logistic Regression     |      0.267 |         0.074 |      0.25  |        nan     |
| Severity   | Random Forest           |      0.278 |         0.074 |      0.255 |          0.832 |
| Risk_Level | Majority-class baseline |      0.427 |         0.013 |      0.199 |        nan     |
| Risk_Level | Logistic Regression     |      0.578 |         0.071 |      0.466 |        nan     |
| Risk_Level | Random Forest           |      0.598 |         0.066 |      0.448 |          0.01  |
