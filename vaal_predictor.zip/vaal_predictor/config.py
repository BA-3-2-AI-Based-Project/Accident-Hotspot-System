"""Shared settings and the (illustrative) Vaal zone definitions."""
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

SEED = 42
START, END = "2020-01-01", "2025-12-31"
TRAIN_END, VAL_END = "2023-12-31", "2024-12-31"   # test = 2025 (time-based split)

BLOCKS = ["00-04", "04-08", "08-12", "12-16", "16-20", "20-24"]   # 4-hour windows
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# Approximate, ILLUSTRATIVE accident-prone zones in the Vaal region.
# name, lat, lon, spread (m), relative weight, road type
ZONES = [
    ("R59 / Vanderbijlpark",        -26.715, 27.845, 220, 1.6, "highway"),
    ("Vereeniging CBD",             -26.673, 27.926, 200, 1.3, "urban"),
    ("R82 Sebokeng-Evaton",         -26.570, 27.870, 230, 1.5, "highway"),
    ("Sasolburg Industrial (R42)",  -26.810, 27.830, 220, 0.8, "industrial"),
    ("Meyerton N1 Interchange",     -26.560, 28.020, 230, 1.2, "highway"),
    ("Sharpeville Main Road",       -26.690, 27.870, 180, 0.9, "urban"),
    ("Three Rivers",                -26.660, 27.950, 180, 0.6, "urban"),
    ("Boipatong / Bophelong",       -26.655, 27.800, 190, 0.8, "urban"),
    ("Evaton Main Road",            -26.545, 27.905, 190, 1.0, "urban"),
    ("Barrage Road",                -26.660, 27.900, 170, 0.7, "urban"),
]
BBOX = dict(lat=(-26.86, -26.50), lon=(27.75, 28.08))   # for scattered background accidents

CAUSES = ["speeding", "drunk_driving", "pedestrian", "wet_road", "mechanical_failure", "animal", "distracted_driving"]
