"""AI Accident Hotspot Vaal Predictor - end-to-end prototype.
Usage:  python main.py               train everything + produce outputs/
        python main.py --chat        talk to VaalBot (needs a previous training run)
        python main.py --data my.csv use REAL accident data (columns: datetime, lat, lon [+ rain, severity, narrative, cause, road_type])
"""
import sys, json, warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, joblib
from config import *
import data, hotspots, risk_model as rm, forecast, nlp, chatbot


def main():
    if "--chat" in sys.argv:
        b = joblib.load(OUT / "risk_model.joblib"); chatbot.chat_loop(chatbot.VaalBot(b, b["nlp"])); return
    np.random.seed(SEED)
    # 1. DATA ---------------------------------------------------------------------------------
    if "--data" in sys.argv:
        df = data.clean(data.load_csv(sys.argv[sys.argv.index("--data") + 1]))
        weather = pd.DataFrame({"date": np.repeat(pd.date_range(START, END), 6), "block": np.tile(range(6), len(pd.date_range(START, END))), "rain": 0})
    else:
        df, weather = data.generate(); df = data.clean(df)
        df.to_csv(OUT / "accidents_simulated.csv", index=False)
    df.head(12).to_csv(OUT / "data_sample.csv", index=False)
    print(f"[data] {len(df)} accident records {df.datetime.min().date()} -> {df.datetime.max().date()}")
    # 2. HOTSPOTS (unsupervised: DBSCAN) ----------------------------------------------------------
    df, hs = hotspots.detect(df); hotspots.plot_hotspots(df, hs); hs.to_csv(OUT / "hotspot_ranking.csv", index=False)
    # 3. RISK MODEL (supervised) -----------------------------------------------------------------
    panel = rm.add_zone_history(rm.build_panel(df, hs, weather))
    table, champ, fitted, tr, va, te, probs, drift = rm.train_and_evaluate(panel); rm.plots(table, champ, fitted, te, probs)
    model = fitted[champ]
    cap = {"Random selection": rm.capture_rate(te.y, np.random.rand(len(te)))}
    cap["Champion model"] = rm.capture_rate(te.y, model.predict_proba(te[rm.FEATURES])[:, 1])
    extra = ""
    if not "--data" in sys.argv:
        oa, op = rm.oracle_auc(te, hs, data.generate.last_lam); cap["Oracle (true intensity)"] = rm.capture_rate(te.y, op)
        extra = f"\nTheoretical best ROC-AUC on this simulated data (oracle that knows the true accident rates): **{oa:.3f}**\n"; print(f"[risk] oracle ROC-AUC = {oa:.3f}")
    cap = pd.DataFrame(cap).T; print(cap.round(3).to_string())
    zf = panel.drop_duplicates("cluster").set_index("cluster")[["zone_rate", "zone_rain_ratio", "zone_rush_ratio", "is_highway", "is_urban", "is_industrial"]].to_dict("index")
    p_all = model.predict_proba(te[rm.FEATURES])[:, 1]; cuts = [float(np.quantile(p_all, q)) for q in (.60, .85, .97)]
    # 4. TIME SERIES + LSTM (deep learning) ---------------------------------------------------------
    ts = forecast.daily_series(df, weather); forecast.analysis_plots(df, ts); lstm_res = forecast.run_lstm(ts)
    # 5. NLP ------------------------------------------------------------------------------------
    pipe, nlp_res, top_terms = nlp.train(df)
    # 6. SAVE + MAP + CHATBOT DEMO ------------------------------------------------------------------
    bundle = dict(model=model, hotspots=hs, zone_features=zf, risk_cuts=cuts, nlp=pipe, champion=champ)
    rm.save(bundle)
    bot = chatbot.VaalBot(bundle, pipe)
    risk_now = {r.name: bot.rp.level(bot.rp.predict(r.cluster, 4, 4, 1, 12, 15)) for r in hs.itertuples()}
    hotspots.build_map(df, hs, risk_now)
    demo = ["Hello", "top hotspots", "How risky is Vereeniging on Friday at 17:00 when it is raining?", "risk in Sebokeng Sunday morning",
            "safest time for R59 on Saturday", "report: driver was texting and drifted into the next lane", "how accurate are you?"]
    with open(OUT / "chatbot_demo.txt", "w") as f:
        for q in demo:
            a = bot.reply(q); f.write(f"You: {q}\nVaalBot: {a}\n\n"); print(f"\nYou: {q}\nVaalBot: {a}")
    # 7. METRICS REPORT ---------------------------------------------------------------------------
    with open(OUT / "metrics.md", "w") as f:
        f.write("# Evaluation results (simulated Vaal data; test year = 2025)\n\n## Risk model (zone x 4h-block)\n" + table.round(3).to_markdown() +
                f"\n\nChampion: **{champ}**\n" + extra + "\nShare of test-year accidents reached if patrols cover only the highest-risk windows:\n\n" + cap.round(3).to_markdown() + "\n\nRoc-AUC per year after training (model-drift check):\n\n" + drift.rename("roc_auc").rename_axis("year").round(3).to_markdown() +
                "\n\n## LSTM daily forecast\n" + lstm_res.round(3).to_markdown() + "\n\n## NLP cause classifier\n" +
                pd.Series(nlp_res).round(3).to_frame("score").to_markdown() + "\n\nTop words per cause:\n" + "\n".join(f"- {k}: {', '.join(v)}" for k, v in top_terms.items()) + "\n")
    print("\nDONE - see the outputs/ folder (open outputs/hotspot_map.html in a browser).")


if __name__ == "__main__":
    main()
