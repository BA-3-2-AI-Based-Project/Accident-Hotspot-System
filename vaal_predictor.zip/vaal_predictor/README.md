p# AI Accident Hotspot Vaal Predictor – Python prototype

Run:
    pip install -r requirements.txt
    python main.py            # trains everything, writes outputs/
    python main.py --chat     # talk to VaalBot
    python main.py --data Accident_Dataset   # real data: columns datetime, lat, lon (+ rain, severity, narrative, cause, road_type)

| File | Rubric item |
|---|---|
| data.py | Data (simulated Vaal accidents + weather feed, cleaning, real-CSV loader) |
| hotspots.py | ML approach – unsupervised DBSCAN hotspots, heat-map (outputs/hotspot_map.html) |
| risk_model.py | ML approach + Model evaluation + Solution techniques (class weights, tuning, time-series CV, time-based split, baselines) |
| forecast.py | Time-series analysis + Deep learning (LSTM) |
| nlp.py | NLP – cause-of-accident classifier from narrative text |
| chatbot.py | Chatbot (VaalBot) |

IMPORTANT: the accident data is SIMULATED (no real crash records). Results show the pipeline works, not real-world accuracy.
Replace with real records (e.g. traffic-authority / RTMC / municipal data) and rerun.
