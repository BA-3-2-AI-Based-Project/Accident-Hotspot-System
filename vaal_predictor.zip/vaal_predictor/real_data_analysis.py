"""Analysis of the REAL Vaal accident dataset (150 records, Accident_Dataset.csv).
Usage: python real_data_analysis.py path/to/Accident_Dataset.csv
Honest design: hotspots (spatial) + descriptive patterns + cross-validated models that are compared with a majority-class baseline
and a permutation test, because 150 records are too few to assume anything is predictable."""
import sys, warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, folium
from folium.plugins import HeatMap
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.cluster import DBSCAN
from sklearn.metrics import adjusted_rand_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import RepeatedStratifiedKFold, cross_validate, permutation_test_score
from config import OUT, SEED

CSV = sys.argv[1]
d = pd.read_csv(CSV)
d["datetime"] = pd.to_datetime(d.Date + " " + d.Time)
d["hour"] = d.datetime.dt.hour
d["weekday"] = d.datetime.dt.day_name()                      # recomputed from the date
mismatch = (d.weekday != d.Day_of_Week).mean()
d["month"] = d.datetime.dt.to_period("M")
d["rain"] = (d.Weather == "Rainy").astype(int)
d["period"] = pd.cut(d.hour, [-1, 5, 10, 16, 20, 24], labels=["Night", "Morning peak", "Midday", "Evening peak", "Late night"])
print(f"[data] {len(d)} records, {d.datetime.min().date()} -> {d.datetime.max().date()}; Day_of_Week column wrong in {mismatch:.0%} of rows (recomputed from Date)")

# ---------- 1. hotspots with DBSCAN ------------------------------------------------------------
X = np.radians(d[["Latitude", "Longitude"]].values)
lab = DBSCAN(eps=0.8 / 6371.0088, min_samples=5, metric="haversine", algorithm="ball_tree").fit_predict(X)
d["cluster"] = lab
ari = adjusted_rand_score(d.Location_Name, lab)
print(f"[hotspots] DBSCAN: {len(set(lab)-{-1})} clusters, {np.mean(lab==-1):.0%} noise; agreement with Location_Name (adj. Rand) = {ari:.2f}")
sev_w = {"Minor Injury": 1, "Serious Injury": 3, "Fatal": 10}
rows = []
for c, g in d[d.cluster >= 0].groupby("cluster"):
    rows.append(dict(cluster=c, location=g.Location_Name.mode()[0], lat=g.Latitude.mean(), lon=g.Longitude.mean(), accidents=len(g),
                     fatal=int((g.Severity == "Fatal").sum()), fatal_pct=(g.Severity == "Fatal").mean(), rain_pct=g.rain.mean(),
                     top_cause=g.Cause_of_Accident.mode()[0], peak_period=g.period.mode()[0], high_risk_pct=(g.Risk_Level == "High").mean(),
                     severity_score=int(g.Severity.map(sev_w).sum())))
hs = pd.DataFrame(rows).sort_values("severity_score", ascending=False).reset_index(drop=True); hs.insert(0, "rank", hs.index + 1)
hs.to_csv(OUT / "real_hotspot_ranking.csv", index=False); print(hs[["rank", "location", "accidents", "fatal", "top_cause", "peak_period"]].to_string(index=False))

m = folium.Map([d.Latitude.mean(), d.Longitude.mean()], zoom_start=10, tiles="CartoDB positron")
HeatMap(d[["Latitude", "Longitude"]].values.tolist(), radius=14, blur=16, min_opacity=.3).add_to(m)
for r in hs.itertuples():
    col = "red" if r.rank <= 3 else "orange" if r.rank <= 6 else "green"
    folium.CircleMarker([r.lat, r.lon], radius=6 + 14 * r.accidents / hs.accidents.max(), color=col, fill=True, fill_opacity=.45,
        popup=folium.Popup(f"<b>#{r.rank} {r.location}</b><br>{r.accidents} accidents, {r.fatal} fatal ({r.fatal_pct:.0%})<br>Top cause: {r.top_cause}<br>Peak: {r.peak_period}<br>In rain: {r.rain_pct:.0%}", max_width=280)).add_to(m)
m.save(OUT / "real_hotspot_map.html")

fig, ax = plt.subplots(figsize=(8, 6.5)); cm = plt.get_cmap("tab10")
for c, g in d.groupby("cluster"): ax.scatter(g.Longitude, g.Latitude, s=22, color="#bbb" if c < 0 else cm(c % 10))
for r in hs.itertuples(): ax.annotate(f"#{r.rank} {r.location.split(' - ')[1]}", (r.lon, r.lat), fontsize=7, xytext=(5, 5), textcoords="offset points", bbox=dict(boxstyle="round,pad=.2", fc="white", ec="none", alpha=.8))
ax.set(title="Real Vaal accidents - DBSCAN hotspots (n=150)", xlabel="Longitude", ylabel="Latitude"); fig.tight_layout(); fig.savefig(OUT / "real_01_hotspots.png", dpi=150); plt.close(fig)

# ---------- 2. descriptive patterns -----------------------------------------------------------
fig, axs = plt.subplots(2, 3, figsize=(16, 8.5))
d.groupby("hour").size().reindex(range(24), fill_value=0).plot.bar(ax=axs[0, 0], color="#3b6ea5"); axs[0, 0].set(title="Accidents by hour of day", xlabel="hour")
order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
d.weekday.value_counts().reindex(order).plot.bar(ax=axs[0, 1], color="#3b6ea5"); axs[0, 1].set(title="By weekday (recomputed from Date)", xlabel="")
d.Cause_of_Accident.value_counts().sort_values().plot.barh(ax=axs[0, 2], color="#3b6ea5"); axs[0, 2].set(title="Reported cause")
pd.crosstab(d.Location_Name.str.split(" - ").str[1], d.Severity)[["Minor Injury", "Serious Injury", "Fatal"]].loc[hs.location.str.split(" - ").str[1]].plot.barh(stacked=True, ax=axs[1, 0], color=["#9ecae1", "#fd8d3c", "#a50f15"]); axs[1, 0].invert_yaxis(); axs[1, 0].set(title="Severity by hotspot (ranked)", ylabel="")
d.groupby("month").size().plot(ax=axs[1, 1], marker="o", color="#c0392b"); axs[1, 1].set(title="Accidents per month (only 23 months)", xlabel="")
sns.heatmap(pd.crosstab(d.Weather, d.Risk_Level, normalize="index")[["Low", "Medium", "High"]], annot=True, fmt=".0%", cmap="YlOrRd", ax=axs[1, 2], cbar=False); axs[1, 2].set(title="Recorded Risk_Level by weather", ylabel="")
fig.tight_layout(); fig.savefig(OUT / "real_02_patterns.png", dpi=150); plt.close(fig)

# ---------- 3. predictive models with honest validation ----------------------------------------
num, cat = ["hour", "rain"], ["weekday", "Weather", "Road_Type", "Road_Condition", "Traffic_Volume", "Cause_of_Accident", "cluster"]
d["cluster"] = d.cluster.astype(str)
pre = ColumnTransformer([("n", StandardScaler(), num), ("c", OneHotEncoder(handle_unknown="ignore"), cat)])
models = {"Majority-class baseline": DummyClassifier(strategy="most_frequent"),
          "Logistic Regression": make_pipeline(pre, LogisticRegression(max_iter=1000, C=0.3)),
          "Random Forest": make_pipeline(pre, RandomForestClassifier(300, min_samples_leaf=3, random_state=SEED))}
cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=SEED)
out = []
for target in ["Severity", "Risk_Level"]:
    feats = num + cat if target != "Severity" else num + cat
    y = d[target]
    for name, mdl in models.items():
        r = cross_validate(mdl, d[feats], y, cv=cv, scoring=["accuracy", "f1_macro"])
        row = dict(target=target, model=name, accuracy=r["test_accuracy"].mean(), accuracy_sd=r["test_accuracy"].std(), macro_f1=r["test_f1_macro"].mean())
        if name == "Random Forest":
            _, _, p = permutation_test_score(mdl, d[feats], y, cv=RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=SEED), n_permutations=100, scoring="accuracy", random_state=SEED, n_jobs=-1)
            row["perm_p_value"] = p
        out.append(row)
res = pd.DataFrame(out); print(res.round(3).to_string(index=False))

# weather -> risk level is the only statistically supported link: show it with a simple model summary
rf = models["Random Forest"].fit(d[num + cat], d["Risk_Level"])
names = rf.named_steps["columntransformer"].get_feature_names_out(); imp = pd.Series(rf[-1].feature_importances_, index=names).sort_values().tail(10)
fig, axs = plt.subplots(1, 2, figsize=(14, 4.5))
rp = res.pivot(index="target", columns="model", values="accuracy"); rp.plot.bar(ax=axs[0], rot=0, color=["#3b6ea5", "#999", "#c0392b"]); axs[0].set(title="5x10-fold CV accuracy vs majority baseline", ylabel="accuracy"); axs[0].legend(fontsize=7)
imp.plot.barh(ax=axs[1], color="#3b6ea5"); axs[1].set_title("Random-forest feature importance (Risk_Level)"); fig.tight_layout(); fig.savefig(OUT / "real_03_model_validation.png", dpi=150); plt.close(fig)

# ---------- 4. report --------------------------------------------------------------------------
with open(OUT / "real_data_report.md", "w") as f:
    f.write(f"# Real dataset analysis (n={len(d)})\n\n- Period: {d.datetime.min().date()} to {d.datetime.max().date()}\n- Day_of_Week column disagrees with the real weekday of Date in {mismatch:.0%} of rows (recomputed)\n"
            f"- DBSCAN: {len(hs)} hotspots, {np.mean(lab==-1):.0%} noise; adjusted Rand vs Location_Name = {ari:.2f}\n\n## Hotspot ranking\n{hs.round(2).to_markdown(index=False)}\n\n## Cross-validated models\n{res.round(3).to_markdown(index=False)}\n")
print("DONE")
