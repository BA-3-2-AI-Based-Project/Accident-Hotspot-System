"""Synthetic Vaal-style accident data + loader for real CSVs.

!! The generated data is SIMULATED (no real crash records were available). It encodes realistic
   patterns (rush hours, Fridays, rain, December, month-end paydays, hotspot zones) so the whole
   pipeline can be developed and tested. To use real data, call load_csv() - see its docstring.
"""
import numpy as np
import pandas as pd
from config import *

NARR = {
 "speeding": ["Driver lost control at high speed and hit the barrier.", "Vehicle travelling too fast overturned on the bend.",
              "Excessive speed was a factor, car veered off the road.", "Speeding bakkie rear-ended a stationary taxi."],
 "drunk_driving": ["Suspected drunk driver crossed into oncoming lane.", "Driver smelled of alcohol after the collision.",
                   "Intoxicated motorist hit a parked vehicle late at night.", "Alcohol suspected, driver swerved and struck a pole."],
 "pedestrian": ["Pedestrian knocked down while crossing the road.", "Person walking on the roadside was struck by a vehicle.",
                "Child ran across the street and was hit by a car.", "Pedestrian crossing outside a crosswalk was injured."],
 "wet_road": ["Vehicle skidded on the wet road during heavy rain.", "Slippery surface after the storm caused a collision.",
              "Car aquaplaned and slammed into the median.", "Poor visibility in rain, two cars collided."],
 "mechanical_failure": ["Brake failure caused the truck to hit traffic.", "Tyre burst and the vehicle rolled.",
                        "Mechanical fault, steering locked before impact.", "Truck broke down and was hit from behind."],
 "animal": ["Driver swerved to avoid a cow on the road.", "Vehicle collided with a stray animal.", "Donkey on the road caused a night-time crash."],
 "distracted_driving": ["Driver was on the phone and drifted into another lane.", "Distracted driver failed to stop at the red robot.",
                        "Motorist looked away and rear-ended the car ahead.", "Driver texting when the collision happened."],
}
VAGUE = ["Collision between two vehicles.", "Accident reported, vehicles damaged.", "Crash at the intersection, police attended.",
         "Two vehicles involved, injuries reported."]


def _block_factors():
    return np.array([0.45, 1.35, 0.95, 1.0, 1.9, 0.9])


def generate(seed=SEED):
    """Simulate accidents from an underlying intensity per zone x day x 4h-block.
    Returns (accidents, weather). Weather is a SEPARATE feed (like a weather API) so rain is known for every block."""
    rng = np.random.default_rng(seed)
    days = pd.date_range(START, END, freq="D")
    nd, nz = len(days), len(ZONES)
    month = days.month.values
    # daily rain: rainy Highveld summers, dry winters; storms mostly in the afternoon/evening
    p_rain = np.where(np.isin(month, [11, 12, 1, 2, 3]), 0.32, np.where(np.isin(month, [4, 10]), 0.12, 0.04))
    rainy = rng.random(nd) < p_rain
    block_rain_p = np.array([0.35, 0.4, 0.5, 0.8, 0.8, 0.5])
    rain = rainy[:, None] & (rng.random((nd, 6)) < block_rain_p)           # (days, blocks)

    dow = days.dayofweek.values
    f_dow = np.array([1.0, 0.95, 1.0, 1.05, 1.4, 1.2, 0.9])[dow]
    f_month = np.where(month == 12, 1.3, 1.0)
    dom = days.day.values
    f_pay = np.where((dom >= 24) | (dom <= 2), 1.2, 1.0)                    # month-end payday

    base = 0.04
    w = np.array([z[4] for z in ZONES])
    lam = (base * w[None, :, None]
           * (f_dow * f_month * f_pay)[:, None, None]
           * _block_factors()[None, None, :]
           * np.where(rain, 1.7, 1.0)[:, None, :])                         # (days, zones, blocks)
    counts = rng.poisson(lam)
    generate.last_lam = lam          # true intensity (days, zones, blocks) - lets us compute the theoretical best score

    rows = []
    for d, zi, b in zip(*np.nonzero(counts)):
        for _ in range(counts[d, zi, b]):
            rows.append((d, zi, b))
    ev = pd.DataFrame(rows, columns=["d", "zone", "block"])
    # background (scattered) accidents - these should NOT form hotspots
    n_bg = int(0.2 * len(ev))
    bg = pd.DataFrame({"d": rng.integers(0, nd, n_bg), "zone": -1, "block": rng.choice(6, n_bg, p=_block_factors() / _block_factors().sum())})
    ev = pd.concat([ev, bg], ignore_index=True)

    lat, lon = np.zeros(len(ev)), np.zeros(len(ev))
    for i, z in enumerate(ZONES):
        m = (ev.zone == i).values
        s = z[3] / 111_000.0
        lat[m] = z[1] + rng.normal(0, s, m.sum())
        lon[m] = z[2] + rng.normal(0, s / np.cos(np.radians(26.7)), m.sum())
    m = (ev.zone == -1).values
    lat[m] = rng.uniform(*BBOX["lat"], m.sum()); lon[m] = rng.uniform(*BBOX["lon"], m.sum())

    hour = ev.block * 4 + rng.integers(0, 4, len(ev))
    minute = rng.integers(0, 60, len(ev))
    ev["datetime"] = days[ev.d] + pd.to_timedelta(hour, unit="h") + pd.to_timedelta(minute, unit="m")
    ev["lat"], ev["lon"] = lat, lon
    ev["rain"] = rain[ev.d.values, ev.block.values].astype(int)
    ev["road_type"] = [ZONES[z][5] if z >= 0 else "rural" for z in ev.zone]

    # cause depends on context
    causes = []
    for h, r in zip(hour, ev.rain):
        p = np.array([1.3, 0.5 + (h >= 20 or h < 5) * 1.2, 0.9, 0.2 + r * 2.2, 0.5, 0.2 + (h >= 20 or h < 5) * 0.5, 0.9])
        causes.append(rng.choice(CAUSES, p=p / p.sum()))
    ev["cause"] = causes
    p_fatal = 0.04 + 0.05 * ((hour >= 20) | (hour < 5)) + 0.03 * ev.rain.values
    p_ser = 0.25
    u = rng.random(len(ev))
    ev["severity"] = np.where(u < p_fatal, "fatal", np.where(u < p_fatal + p_ser, "serious", "minor"))
    ev["narrative"] = [rng.choice(VAGUE) if rng.random() < 0.25 else rng.choice(NARR[c]) for c in ev.cause]
    ev["vehicles"] = rng.choice([1, 2, 3, 4], len(ev), p=[0.18, 0.55, 0.22, 0.05])
    ev = ev.sort_values("datetime").reset_index(drop=True)
    ev.insert(0, "accident_id", [f"ACC{i:06d}" for i in range(len(ev))])
    weather = pd.DataFrame({"date": np.repeat(days, 6), "block": np.tile(np.arange(6), nd), "rain": rain.reshape(-1).astype(int)})
    return ev[["accident_id", "datetime", "lat", "lon", "road_type", "rain", "severity", "vehicles", "cause", "narrative"]], weather


def load_csv(path):
    """Load REAL data. Required columns: datetime, lat, lon. Optional: rain (0/1), severity, narrative, cause, road_type."""
    df = pd.read_csv(path, parse_dates=["datetime"])
    df = df.dropna(subset=["datetime", "lat", "lon"])
    df = df[df.lat.between(-27.2, -26.2) & df.lon.between(27.4, 28.4)]          # keep Vaal bounding region
    for c, v in [("rain", 0), ("severity", "unknown"), ("road_type", "urban"), ("narrative", ""), ("cause", "unknown"), ("vehicles", 1)]:
        if c not in df: df[c] = v
    return df.drop_duplicates().reset_index(drop=True)


def clean(df):
    """Handle missing / incorrect values (requirement: 'Clean accident data')."""
    n0 = len(df)
    df = df.drop_duplicates("accident_id") if "accident_id" in df else df.drop_duplicates()
    df = df.dropna(subset=["datetime", "lat", "lon"])
    df = df[df.lat.between(-27.2, -26.2) & df.lon.between(27.4, 28.4)]
    df["narrative"] = df["narrative"].fillna("")
    print(f"[clean] {n0} -> {len(df)} records kept")
    return df.reset_index(drop=True)
