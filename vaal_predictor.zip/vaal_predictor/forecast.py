"""Time-series analysis + LSTM deep-learning forecast of DAILY accident counts (region-wide)."""
import os; os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from config import *

WINDOW = 28   # the LSTM looks at the previous 28 days


def daily_series(df, weather):
    s = df.set_index(df.datetime.dt.normalize()).groupby(level=0).size().reindex(pd.date_range(START, END, freq="D"), fill_value=0)
    out = pd.DataFrame({"count": s.values}, index=s.index)
    out["rain_frac"] = weather.groupby("date").rain.mean().reindex(out.index).values
    out["dow_s"], out["dow_c"] = np.sin(2*np.pi*out.index.dayofweek/7), np.cos(2*np.pi*out.index.dayofweek/7)
    out["mon_s"], out["mon_c"] = np.sin(2*np.pi*out.index.month/12), np.cos(2*np.pi*out.index.month/12)
    out["payday"] = ((out.index.day >= 24) | (out.index.day <= 2)).astype(float)
    return out


def analysis_plots(df, ts):
    """Trend / seasonality / hour-of-week pattern plots."""
    fig, axs = plt.subplots(2, 2, figsize=(13, 8))
    ts["count"].resample("W").sum().plot(ax=axs[0, 0], lw=.8, color="#999"); ts["count"].resample("W").sum().rolling(8, center=True).mean().plot(ax=axs[0, 0], lw=2, color="#c0392b")
    axs[0, 0].set(title="Weekly accidents (grey) and 8-week trend (red)", xlabel="", ylabel="accidents / week")
    ts.groupby(ts.index.month)["count"].mean().plot.bar(ax=axs[0, 1], color="#3b6ea5"); axs[0, 1].set(title="Seasonality: average accidents per day by month", xlabel="Month")
    piv = df.assign(h=df.datetime.dt.hour // 4, d=df.datetime.dt.dayofweek).pivot_table(index="d", columns="h", values="accident_id", aggfunc="count")
    piv.index = [d[:3] for d in DAYS]; piv.columns = BLOCKS
    sns.heatmap(piv, cmap="YlOrRd", ax=axs[1, 0], annot=True, fmt="d", cbar=False); axs[1, 0].set(title="When do accidents happen? (day x 4-hour block)", xlabel="", ylabel="")
    rr = ts.assign(r=np.where(ts.rain_frac > 0, "Rain", "Dry")).groupby("r")["count"].mean()
    rr.plot.bar(ax=axs[1, 1], color=["#2c7fb8", "#d95f0e"], rot=0); axs[1, 1].set(title="Average accidents per day: dry vs rainy", xlabel="")
    for p in axs[1, 1].patches: axs[1, 1].annotate(f"{p.get_height():.2f}", (p.get_x()+p.get_width()/2, p.get_height()), ha="center", va="bottom")
    fig.tight_layout(); fig.savefig(OUT / "03_time_series_analysis.png", dpi=150); plt.close(fig)


def make_windows(ts, scale):
    feats = ts[["count", "rain_frac", "dow_s", "dow_c", "mon_s", "mon_c", "payday"]].copy(); feats["count"] /= scale
    X, N, y, dates = [], [], [], []
    A = feats.values
    for i in range(WINDOW, len(ts)):
        X.append(A[i-WINDOW:i])                      # past 28 days (incl. past counts)
        N.append(A[i, 1:])                           # next-day KNOWN info: rain forecast, weekday, month, payday
        y.append(ts["count"].iloc[i]); dates.append(ts.index[i])
    return np.array(X, "float32"), np.array(N, "float32"), np.array(y, "float32"), pd.DatetimeIndex(dates)


def run_lstm(ts, epochs=60):
    import tensorflow as tf
    tf.keras.utils.set_random_seed(SEED)
    scale = float(ts["count"][:TRAIN_END].mean() * 2)
    X, N, y, d = make_windows(ts, scale)
    tr, va, te = d <= TRAIN_END, (d > TRAIN_END) & (d <= VAL_END), d > VAL_END
    seq = tf.keras.Input((WINDOW, X.shape[2])); nxt = tf.keras.Input((N.shape[1],))
    h = tf.keras.layers.LSTM(32)(seq); h = tf.keras.layers.Dropout(.15)(h)
    h = tf.keras.layers.Concatenate()([h, nxt]); h = tf.keras.layers.Dense(16, activation="relu")(h)
    out = tf.keras.layers.Dense(1, activation="softplus")(h)
    model = tf.keras.Model([seq, nxt], out); model.compile("adam", "mae")
    hist = model.fit([X[tr], N[tr]], y[tr] / scale, validation_data=([X[va], N[va]], y[va] / scale), epochs=epochs, batch_size=32, verbose=0,
                     callbacks=[tf.keras.callbacks.EarlyStopping(patience=8, restore_best_weights=True)])
    pred = model.predict([X[te], N[te]], verbose=0).ravel() * scale
    actual = y[te]; dte = d[te]
    s = ts["count"]
    base_mean7 = s.rolling(7).mean().shift(1).reindex(dte).values          # naive: average of last 7 days
    base_week = s.shift(7).reindex(dte).values                              # naive: same weekday last week
    mae = lambda p: float(np.mean(np.abs(actual - p))); rmse = lambda p: float(np.sqrt(np.mean((actual - p) ** 2)))
    res = pd.DataFrame({"MAE": {"Naive: last-7-day mean": mae(base_mean7), "Naive: same weekday last week": mae(base_week), "LSTM": mae(pred)},
                        "RMSE": {"Naive: last-7-day mean": rmse(base_mean7), "Naive: same weekday last week": rmse(base_week), "LSTM": rmse(pred)}})
    print(f"[lstm] trained {len(hist.history['loss'])} epochs\n{res.round(3).to_string()}")
    fig, axs = plt.subplots(1, 2, figsize=(14, 4.2))
    axs[0].plot(hist.history["loss"], label="train loss"); axs[0].plot(hist.history["val_loss"], label="validation loss"); axs[0].set(title="LSTM learning curve", xlabel="epoch", ylabel="MAE (scaled)"); axs[0].legend()
    show = slice(0, 90)
    axs[1].plot(dte[show], actual[show], color="#888", marker="o", ms=3, lw=.8, label="Actual"); axs[1].plot(dte[show], pred[show], color="#c0392b", lw=2, label="LSTM forecast")
    axs[1].set(title="LSTM next-day forecast – first 90 days of the 2025 test year", ylabel="accidents / day"); axs[1].legend(); fig.autofmt_xdate()
    fig.tight_layout(); fig.savefig(OUT / "04_lstm_forecast.png", dpi=150); plt.close(fig)
    model.save(OUT / "lstm_daily_forecast.keras")
    return res
